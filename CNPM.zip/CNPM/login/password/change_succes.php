<?php
	if(!defined("TEMPLATE_PASS")){
		echo "Bạn không có quyền truy cập file này"."<br/>"; ?>
		
		<button><a href="../login.php">Trở về</a></button>
	<?php	die('');
    }?>

<div id="order-success">
                	<div class="row">
                    	<div id="order-success-img" class="col-lg-3 col-md-3 col-sm-12"></div>
                        <div id="order-success-txt" class="col-lg-9 col-md-9 col-sm-12">
                        	<h3>Bạn đã đổi mật khẩu thành công !</h3>
                            <p>Vui lòng quay lại trang đăng nhập.</p>
                            <a href="../login.php" class="btn btn-success">Trở lại</a>
                        </div>
                    </div>    
                </div>