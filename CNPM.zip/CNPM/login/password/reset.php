<?php
define("TEMPLATE_PASS", true);
ob_start();
session_start();
include_once("../connect.php");
include_once("admin_pass.php");
?>