// CONFIG
const format = "image/png";
const minX = 102.107963562012;
const minY = 8.30629730224609;
const maxX = 109.505790710449;
const maxY = 23.4677505493164;
const cenX = (minX + maxX) / 2;
const cenY = (minY + maxY) / 2;
const mapLat = cenY;
const mapLng = cenX;
const mapDefaultZoom = 6;

const ImageWMSConfig = {
  ratio: 1,
  url: "https://gis.namdd72.tech/geoserver/GIS/wms?",
  params: {
    FORMAT: format,
    VERSION: "1.1.1",
    STYLES: "",
  },
};

// END CONFIG

const provinceLayer = new ol.layer.Image({
  source: new ol.source.ImageWMS({
    ...ImageWMSConfig,
    params: {
      ...ImageWMSConfig.params,
      LAYERS: "gadm36_vnm_1",
    },
  }),
});

const districtLayer = new ol.layer.Image({
  source: new ol.source.ImageWMS({
    ...ImageWMSConfig,
    params: {
      ...ImageWMSConfig.params,
      LAYERS: "gadm36_vnm_2",
    },
  }),
});

const villageLayer = new ol.layer.Image({
  source: new ol.source.ImageWMS({
    ...ImageWMSConfig,
    params: {
      ...ImageWMSConfig.params,
      LAYERS: "gadm36_vnm_3",
    },
  }),
});

function addLayer(layer) {
  map.addLayer(layer);
}

function removeLayer(layer) {
  map.removeLayer(layer);
}

function setValPopup(reset, data) {
  const {
    province_name,
    province_type,
    district_name,
    district_type,
    village_name,
    village_type,
    area,
    population,
    countryside,
    city,
    density,
  } = data;
  const objectChecked = $("input:radio[name='object']:checked").val();
  let popupType, popupName;
  switch (objectChecked) {
    case "gadm36_vnm_1":
      $("#districtPopup").addClass("d-none");
      $("#provincePopup").addClass("d-none");
      popupType = province_type;
      popupName = province_name;
      break;
    case "gadm36_vnm_2":
      $("#districtPopup").removeClass("d-none");
      $("#provincePopup").addClass("d-none");
      popupType = district_type;
      popupName = district_name;
      $("#districtName").text(reset || !province_name ? "N/A" : province_name);
      $("#districtType").text(reset || !province_type ? "N/A" : province_type);
      break;
    case "gadm36_vnm_3":
      $("#districtPopup").removeClass("d-none");
      $("#provincePopup").removeClass("d-none");
      popupType = village_type;
      popupName = village_name;
      $("#districtName").text(reset || !district_name ? "N/A" : district_name);
      $("#districtType").text(reset || !district_type ? "N/A" : district_type);
      $("#provinceName").text(reset || !province_name ? "N/A" : province_name);
      $("#provinceType").text(reset || !province_type ? "N/A" : province_type);
      break;
    default:
      break;
  }
  $("#popupName").text(reset || !popupName ? "N/A" : popupName);
  $("#popupType").text(reset || !popupType ? "N/A" : popupType);
  $("#areaPopup").text(reset || !area ? "N/A" : parseFloat(area).toFixed(1));
  $("#populationPopup").text(reset || !population ? "N/A" : population);
  $("#countrySidePopup").text(reset || !countryside ? "N/A" : countryside);
  $("#cityPopup").text(reset || !city ? "N/A" : city);
  $("#densityPopup").text(reset || !density ? "N/A" : density);
}

let overlay,
  popupCovid,
  idCovid,
  element,
  map,
  draw,
  vectorLayer,
  covidLayer,
  drawLayer,
  closer,
  status = "Info",
  clickedCoord = {},
  arrLayersPoint = [],
  arrLayers = [],
  actionModal;

const source = new ol.source.Vector();

function startDrawing() {
  // add interaction to the map
  map.addInteraction(draw);
}

function initialize_map() {
  $(document).ready(function () {
    layerBG = new ol.layer.Tile({
      source: new ol.source.OSM({}),
    });

    const viewMap = new ol.View({
      center: ol.proj.fromLonLat([mapLng, mapLat]),
      zoom: mapDefaultZoom,
      //projection: projection
    });

    const container = document.getElementById("popup");
    element = document.getElementById("popupCovid");
    closer = document.getElementById("popup-closer");
    /**
     * Create an overlay to anchor the popup to the map.
     */
    overlay = new ol.Overlay({
      element: container,
      autoPan: true,
      autoPanAnimation: {
        duration: 250,
      },
    });

    closer.onclick = () => {
      overlay.setPosition(undefined);
      closer.blur();
      return false;
    };

    map = new ol.Map({
      target: "map",
      layers: [layerBG, provinceLayer],
      //layers: [layerCMR_adm1],
      view: viewMap,
      overlays: [overlay],
    });

    //  1. To define a source
    const drawSource = new ol.source.Vector();
    // 2. To Define a style
    // Skip it and let the OL use default styling
    // 3. To Define a Layer
    drawLayer = new ol.layer.Vector({
      source: drawSource,
    });
    // 4. Adding on map
    map.addLayer(drawLayer);

    // Initiate a draw interaction
    draw = new ol.interaction.Draw({
      type: "Point",
      source: drawSource,
    });

    draw.on("drawstart", function (evt) {
      drawSource.clear();
    });

    draw.on("drawend", function (evt) {
      $("#myModal").modal("show");
      const coordinate = ol.proj.transform(
        evt.feature.getGeometry().getCoordinates(),
        "EPSG:3857",
        "EPSG:4326"
      );
      clickedCoord["long"] = parseFloat(coordinate[0].toFixed(13));
      clickedCoord["lat"] = parseFloat(coordinate[1].toFixed(13));
      map.removeInteraction(draw);
    });

    // Function that enables draw interaction

    const styles = {
      MultiPolygon: new ol.style.Style({
        fill: new ol.style.Fill({
          color: "#319FD3",
          zIndex: 99,
        }),
        stroke: new ol.style.Stroke({
          color: "#fff",
          width: 3,
          zIndex: 99,
        }),
      }),
    };

    const styleFunction = (feature) => {
      return styles[feature.getGeometry().getType()];
    };

    const stylePopulation = (feature, population, text) => {
      return {
        MultiPolygon: new ol.style.Style({
          fill: new ol.style.Fill({
            color: colorPopulation(population),
            zIndex: 10,
          }),
          stroke: new ol.style.Stroke({
            color: "#fff",
            width: 1,
            zIndex: 10,
          }),
          geometry: function (feature) {
            let geometry = feature.getGeometry();
            if (geometry.getType() == "MultiPolygon") {
              // Only render label for the widest polygon of a multipolygon
              let polygons = geometry.getPolygons();
              let widest = 0;
              for (let i = 0, ii = polygons.length; i < ii; ++i) {
                let polygon = polygons[i];
                let width = ol.extent.getWidth(polygon.getExtent());
                if (width > widest) {
                  widest = width;
                  geometry = polygon;
                }
              }
            }
            return geometry;
          },
          text: new ol.style.Text({
            font: "9px Calibri,sans-serif",
            fill: new ol.style.Fill({
              color: "#000",
            }),
            stroke: new ol.style.Stroke({
              color: "#fff",
              width: 3,
            }),
            text: text,
            overflow: true,
          }),
        }),
      }[feature.getGeometry().getType()];
    };

    const stylePoint = (feature, status) => {
      return {
        Point: new ol.style.Style({
          image: new ol.style.Circle({
            radius: 4,
            fill: new ol.style.Fill({
              color: "#f00",
              width: 4,
            }),
            stroke: new ol.style.Stroke({
              color: "#fff",
              width: 2,
            }),
          }),
        }),
      }[feature.getGeometry().getType()];
    };

    vectorLayer = new ol.layer.Vector({
      // source: vectorSource,
      style: styleFunction,
    });
    map.addLayer(vectorLayer);

    const highLightGeoJsonObj = (result, _vectorLayer) => {
      const data = {
        type: "FeatureCollection",
        crs: {
          type: "name",
          properties: {
            name: "EPSG:4326",
          },
        },
        features: [
          {
            type: "Feature",
            geometry: JSON.parse(result),
          },
        ],
      };
      const vectorSource = new ol.source.Vector({
        features: new ol.format.GeoJSON().readFeatures(data, {
          dataProjection: "EPSG:4326",
          featureProjection: "EPSG:3857",
        }),
      });
      _vectorLayer.setSource(vectorSource);
    };

    $("input:checkbox[name='features']").change(function () {
      if ($("#populationCheckbox").is(":checked")) {
        $.ajax({
          type: "GET",
          url: "population.php",
          dataType: "json",
          data: {},
          success: function (result) {
            if ($("#populationCheckbox").is(":checked")) {
              result?.data?.length &&
                result?.data.forEach((elem) => {
                  const nameLayer = `newLayer${
                    map.getLayers().getArray()?.length
                  }`;
                  let _layer = {};
                  _layer[nameLayer] = new ol.layer.Vector({
                    source: new ol.source.Vector({
                      features: new ol.format.GeoJSON().readFeatures(
                        {
                          type: "FeatureCollection",
                          crs: {
                            type: "name",
                            properties: {
                              name: "EPSG:4326",
                            },
                          },
                          features: [
                            {
                              type: "Feature",
                              geometry: JSON.parse(elem.geo),
                            },
                          ],
                        },
                        {
                          dataProjection: "EPSG:4326",
                          featureProjection: "EPSG:3857",
                        }
                      ),
                    }),
                    style: (feature) =>
                      stylePopulation(
                        feature,
                        elem.population,
                        elem?.province_name
                      ),
                  });
                  map.addLayer(_layer[nameLayer]);
                  _layer[nameLayer].setZIndex(500);
                  arrLayers.push(_layer[nameLayer]);
                });
            }
          },
          error: function (req, status, error) {
            console.log(req, status, error);
            alert("SQL Failed!");
            // alert(req + " " + status + " " + error);
          },
        });
      }

      if ($("#covidCheckbox").is(":checked")) {
        $.ajax({
          type: "GET",
          url: "pointCoordinate.php",
          dataType: "json",
          data: {},
          success: function (result) {
            const features = [];
            result?.data?.length &&
              result?.data.forEach((elem) => {
                features.push({
                  type: "Feature",
                  geometry: JSON.parse(elem.geo),
                });
              });
            if ($("#covidCheckbox").is(":checked")) {
              covidLayer = new ol.layer.Vector({
                source: new ol.source.Vector({
                  features: new ol.format.GeoJSON().readFeatures(
                    {
                      type: "FeatureCollection",
                      crs: {
                        type: "name",
                        properties: {
                          name: "EPSG:4326",
                        },
                      },
                      features: features,
                    },
                    {
                      dataProjection: "EPSG:4326",
                      featureProjection: "EPSG:3857",
                    }
                  ),
                }),
                style: stylePoint,
              });
              map.addLayer(covidLayer);
              covidLayer.setZIndex(1000);
            }
          },
          error: function (req, status, error) {
            console.log(req, status, error);
            alert("SQL Failed!");
            // alert(req + " " + status + " " + error);
          },
        });
      }
    });

    popupCovid = new ol.Overlay({
      element: element,
      // positioning: 'bottom-center',
      stopEvent: false,
      offset: [0, -10],
    });
    map.addOverlay(popupCovid);

    map.on("singleclick", function (evt) {
      const objectChecked = $("input:radio[name='object']:checked").val();
      const coordinate = evt.coordinate;
      if (status === "Info") {
        const lonlat = ol.proj.transform(coordinate, "EPSG:3857", "EPSG:4326");
        const lon = lonlat[0];
        const lat = lonlat[1];
        const paPoint = "POINT(" + lon + " " + lat + ")";
        $.ajax({
          type: "POST",
          url: "InfoCoordinate.php",
          dataType: "json",
          data: {
            paPoint,
            from: objectChecked,
          },
          success: function (result) {
            if (!result?.data) {
              $("#popup").hide();
              vectorLayer.setSource(undefined);
              alert("Server Error!");
            } else {
              $("#popup").show();
              setValPopup(false, result?.data[0]);
            }
            overlay.setPosition(coordinate);
            vectorLayer.setZIndex(700);
            highLightGeoJsonObj(result?.data[0].geo, vectorLayer);
          },
          error: function (req, status, error) {
            console.log(req, status, error);
            alert("SQL Failed!");
            // alert(req + " " + status + " " + error);
          },
        });
      } else {
        if (!map.getFeaturesAtPixel(evt.pixel)?.length) return;
        const feature = map.getFeaturesAtPixel(evt.pixel)[0];
        if (feature) {
          const _coordinate = feature.getGeometry().getCoordinates();
          if(status === "InfoCovid") {
            popupCovid.setPosition(_coordinate);
          }
          const lonlat = ol.proj.transform(
            _coordinate,
            "EPSG:3857",
            "EPSG:4326"
          );
          const lon = parseFloat(lonlat[0].toFixed(13));
          const lat = parseFloat(lonlat[1].toFixed(13));
          const paPoint = "POINT(" + lon + " " + lat + ")";
          $.ajax({
            type: "GET",
            url: "pointCoordinate.php",
            dataType: "json",
            data: {
              paPoint,
            },
            success: function (result) {
              if (!result?.data) {
                $("#popupCovid").addClass("d-none");
              } else {
                if($("#updateCovid").is(":checked")) {
                  $("#myModal h5").text("Cập nhật người nhiễm");
                  idCovid = result?.data[0]?.id;
                  $("#namePerson").val(result?.data[0]?.name);
                  $("#agePerson").val(result?.data[0]?.age);
                  $("#statusPerson").val(result?.data[0]?.status);
                  $("#myModal").modal("show");
                  $("#popupCovid").addClass("d-none");
                } else {
                  $("#nameCovidPopup").text(result?.data[0]?.name);
                  $("#ageCovidPopup").text(result?.data[0]?.age);
                  $("#timeCovidPopup").text(result?.data[0]?.time);
                  $("#statusCovidPopup").text(result?.data[0]?.status === "t" ? "Khỏi bệnh" : "Nhiễm bệnh");
                  $("#popupCovid").removeClass("d-none");
                }
              }
            },
            error: function (req, status, error) {
              console.log(req, status, error);
              alert("SQL Failed!");
              // alert(req + " " + status + " " + error);
            },
          });
        } else {
          $("#popupCovid").addClass("d-none");
        }
      }
    });

    map.on("pointermove", function (event) {
      if (map.hasFeatureAtPixel(event.pixel)) {
        map.getViewport().style.cursor = "pointer";
      } else {
        map.getViewport().style.cursor = "inherit";
      }
    });
  });
}

function colorPopulation(population) {
  const _p = parseFloat(population);
  return _p <= 600
    ? "#49AA62"
    : _p > 600 && _p <= 1200
    ? "#B2DF84"
    : _p > 1200 && _p <= 2400
    ? "#F6BD7C"
    : _p > 2400
    ? "#DB4948"
    : "transparent";
}
