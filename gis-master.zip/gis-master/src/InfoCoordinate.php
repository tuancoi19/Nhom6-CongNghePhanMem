<?php
  require ('utils.php'); 
  if(isset($_POST['paPoint']) && isset($_POST['from'])) {
    $dbConn = connectDB();
    $paSRID = '4326';
    $paPoint = $_POST['paPoint'];
    $from = $_POST['from'];
    $paPoint = str_replace(',', ' ', $paPoint);
    $mySQLStr = "";
    if($from === "gadm36_vnm_3") {
      $mySQLStr = "SELECT 
      G.name_1 AS province_name,
      G.type_1 AS province_type,
      G2.name_2 AS district_name,
      G2.type_2 AS district_type,
      G3.name_3 AS village_name,
      G3.type_3 AS village_type,
      ST_AsGeoJson(G3.geom) AS geo,
      ST_Area(G3.geom, false) / (POWER(10,6)) AS area 
      FROM gadm36_vnm_1 AS G, gadm36_vnm_2 AS G2, gadm36_vnm_3 AS G3
      WHERE 
      ST_Within('SRID=".$paSRID.";".$paPoint."'::geometry, G3.geom)
      AND G.gid_1 = G2.gid_1 AND G2.gid_2 = G3.gid_2";
    } else if ($from === "gadm36_vnm_2")  {
      $mySQLStr = "SELECT 
      G.name_1 AS province_name,
      G.type_1 AS province_type,
      G2.name_2 AS district_name,
      G2.type_2 AS district_type,
      ST_AsGeoJson(G2.geom) AS geo,
      ST_Area(G2.geom, false) / (POWER(10,6)) AS area 
      FROM gadm36_vnm_1 AS G, gadm36_vnm_2 AS G2 
      WHERE 
      ST_Within('SRID=".$paSRID.";".$paPoint."'::geometry, G2.geom)
      AND 
      G.gid_1 = G2.gid_1";
    } else {
      $mySQLStr = "SELECT 
      type_1 AS province_type, 
      ST_AsGeoJson(geom) AS geo, 
      name_1 AS province_name, 
      P.*, 
      ST_Area(geom, false) / (POWER(10,6)) AS area from gadm36_vnm_1 AS G LEFT JOIN Population P ON G.gid = P.provinceid where ST_Within('SRID=".$paSRID.";".$paPoint."'::geometry,geom)";
    }
    $row = query($dbConn, $mySQLStr);
    echo json_encode(["status" => true, "code" => 200, "data" => $row]);
    
  }

?>
