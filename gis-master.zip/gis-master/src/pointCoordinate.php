<?php
  require ('utils.php'); 
  $dbConn = connectDB();
  if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mySQLStr = "";
    if(isset($_POST['action']) && $_POST['action'] === "PUT") {
      if(isset($_POST['name']) && isset($_POST['id'])) {
        $name = $_POST['name'];
        $age = $_POST['age'];
        $status = $_POST['status'];
        $id = $_POST['id'];
        $mySQLStr = "UPDATE covid SET name = '$name', age = $age, status = $status WHERE id = $id";
        $query = pg_query($dbConn, $mySQLStr);
        if ($query) {
          echo json_encode(["code" => 200, "status" => true, "message" => "Updated!"]);
        } else {
          echo json_encode(["code" => 400, "status" => false, "message" => "Update failed!"]);
        }
      } else {
        echo json_encode(["code" => 400, "status" => false, "message" => "Missing info!", "name" => $_POST['name']]);
      }
    } else {
      if(isset($_POST['name']) && isset($_POST['long']) && isset($_POST['lat'])) {
        $name = $_POST['name'];
        $age = $_POST['age'];
        $status = $_POST['status'];
        $long = $_POST['long'];
        $lat = $_POST['lat'];
        $mySQLStr = "INSERT INTO covid(name, age, status, geom) VALUES('$name', $age, false, ST_SetSRID(ST_MakePoint($long, $lat), 4326))";
        $query = pg_query($dbConn, $mySQLStr);
        if ($query) {
          echo json_encode(["code" => 200, "status" => true, "message" => "Added!"]);
        } else {
          echo json_encode(["code" => 400, "status" => false, "message" => "Add failed!"]);
        }
      } else {
        echo json_encode(["code" => 400, "status" => false, "message" => "Missing info!"]);
      } 
    }
  } else {
    if(isset($_GET['paPoint'])) {
      $paSRID = '4326';
      $paPoint = $_GET['paPoint'];
      $mySQLStr = "SELECT * FROM covid WHERE ST_AsText(geom) = '$paPoint'";
    } else {
      $mySQLStr = "SELECT ST_AsGeoJSON(C.geom) as geo, ST_AsText(C.geom) as geo_text FROM covid C";
    }
    $row = query($dbConn, $mySQLStr);
    echo json_encode(["data" => $row, "sql" => $mySQLStr]);  
  }
?>
