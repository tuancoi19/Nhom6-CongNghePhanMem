<?php

  function connectDB() {
    $dbConn = pg_connect("host=150.95.109.21 port=5555 dbname=gis user=postgres password=Gis@123");
    if (!$dbConn) {
      echo "An error occurred.\n";
      exit;
    }
    return $dbConn;
  }

  function query($dbConn, $dbQuery) {
      $result = pg_query($dbConn, $dbQuery);
      if (!$result) {
      // echo $dbQuery;
        echo "Query error.\n";
        exit;
      }
      
      $response = array();
      while ($row = pg_fetch_assoc($result)) {
        $response[] = $row;
      }
      return $response;
    }  
  function closeDB($dbConn) {
    pg_close($dbConn);
  }
