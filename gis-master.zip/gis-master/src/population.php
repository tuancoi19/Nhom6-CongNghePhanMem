<?php
  require ('utils.php'); 
    $dbConn = connectDB();
    $paSRID = '4326';

    $mySQLStr = "SELECT 
    ST_AsGeoJson(G.geom) as geo,
    G.name_1 as province_name,
    P.population
    from gadm36_vnm_1 as G, population as P
    where P.provinceid = G.gid";

    $row = query($dbConn, $mySQLStr);
    echo json_encode(["data" => $row]);
    

?>
