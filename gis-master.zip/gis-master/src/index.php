<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://openlayers.org/en/v4.6.5/css/ol.css" type="text/css" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" type="text/css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js" type="text/javascript"></script>
  <script src="https://openlayers.org/en/v4.6.5/build/ol.js" type="text/javascript"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
  <script src="./script.js" type="text/javascript"></script>
  <link rel="stylesheet" href="./index.css" type="text/css" />
  <title>GIS</title>
</head>
  <body onload="initialize_map();">
  <!-- <div class="col-md-3 col-12 p-0"> -->
    <div class="action-wrapper">
      <div id="header">
        <div class="header-wrapper">
          <div class="title-left">Saturday, November 7<sup>th</sup> 2020</div>
          <i id="collapse" class="fa fa-chevron-down" aria-hidden="true"></i>
        </div>
      </div>
      <div class="main-wrapper">
        <h5 class="title-action">Hiển thị:</h5>
        <span class="checkbox-item">
          <input checked="checked" type="radio" id="province" name="object" value="gadm36_vnm_1">
          <label  for="vehicle1">Tỉnh/Thành phố</label><br>
        </span>
        <span class="checkbox-item">
          <input type="radio" id="district" name="object" value="gadm36_vnm_2">
          <label for="vehicle1">Huyện/Quận</label><br>
        </span>
        <span class="checkbox-item">
          <input type="radio" id="village" name="object" value="gadm36_vnm_3">
          <label for="vehicle1">Xã/Phường</label><br>
        </span>
        <h5 class="title-action">Tính năng</h5>
        <span class="checkbox-item">
          <input type="checkbox" id="populationCheckbox" name="features" value="Info">
          <label for="vehicle1">Thông tin dân số(1000 người)</label><br>
          <div class="info-population">
            <div class="p-600"><span class="txt-info">≤600</span></div>
            <div class="p-1200"><span class="txt-info">≤1200</span></div>
            <div class="p-2400"><span class="txt-info">≤2400</span></div>
            <div class="p-max"><span class="txt-info">>2400</span></div>
          </div>
        <span class="checkbox-item">
          <input type="checkbox" id="covidCheckbox" name="features" value="Covid">
          <label for="vehicle1">Thông tin nhiễm bệnh</label><br>
        </span>
        <h5 class="title-action">Bạn muốn?</h5>
        <span class="checkbox-item">
          <input checked="checked" type="radio" id="info" name="youwant" value="Info">
          <label for="vehicle1">Xem thông tin chi tiết địa điểm</label><br>
        </span>
        <span class="checkbox-item">
          <input type="radio" id="infoCovid" name="youwant" value="InfoCovid">
          <label for="vehicle1">Xem thông tin chi tiết người nhiễm</label><br>
        </span>
        <span class="checkbox-item">
          <input type="radio" id="addCovid" name="youwant" value="addCovid">
          <label for="vehicle1">Thêm người nhiễm</label><br>
        </span>
        <span class="checkbox-item">
          <input type="radio" id="updateCovid" name="youwant" value="updateCovid">
          <label for="vehicle1">Cập nhật người nhiễm</label><br>
        </span>
      </div>

       <!-- POPUP -->

      <div id="popup" class="ol-popup">
        <div class="header-popup">
          <label id="popupType" class="header-label-popup">Province</label>
          <br />
          <span id="popupName" class="header-span-popup"></span>
        </div>
        <div class="main-popup">
          <div id="districtPopup" class="item-popup">
            <label id="districtType" class="label-popup">District</label>
            <br />
            <span id="districtName" class="span-popup"></span>
          </div>
          <div id="provincePopup" class="item-popup">
            <label id="provinceType" class="label-popup">Province</label>
            <br />
            <span id="provinceName" class="span-popup"></span>
          </div>
          <div class="item-popup">
            <label class="label-popup">Diện tích(KM2)</label>
            <br />
            <span id="areaPopup" class="span-popup"></span>
          </div>
          <div class="item-popup">
            <label class="label-popup">Dân số(1000 người)</label>
            <br />
            <span id="populationPopup" class="span-popup"></span>
          </div>
          <div class="item-popup">
            <label class="label-popup">Mật độ(người/KM2)</label>
            <br />
            <span id="densityPopup" class="span-popup"></span>
          </div>
          <div class="item-popup">
            <label class="label-popup">DÂN SỐ THÀNH THỊ (1000 NGƯỜI)</label>
            <br />
            <span id="cityPopup" class="span-popup"></span>
          </div>
          <div class="item-popup">
            <label class="label-popup">DÂN SỐ NÔNG THÔN (1000 NGƯỜI)</label>
            <br />
            <span id="countrySidePopup" class="span-popup"></span>
          </div>
        </div>
        <a href="#" id="popup-closer" class="ol-popup-closer"><i class="fa fa-times" aria-hidden="true"></i></a>
        <div id="popup-content"></div>
      </div>


      <div id="popupCovid" class="ol-popup">
      <a href="#" id="popup-closer-covid" class="ol-popup-closer covid"><i class="fa fa-times" aria-hidden="true"></i></a>
        <table class="m-3">
          <tbody>
            <tr>
              <td>Họ tên: </td>
              <th id="nameCovidPopup"></th>
            </tr>
            <tr>
              <td>Tuổi: </td>
              <th id="ageCovidPopup"></th>
            </tr>
            <tr>
              <td>Ngày nhiễm: </td>
              <th id="timeCovidPopup"></th>
            </tr>
            <tr>
              <td>Tình trạng: </td>
              <th id="statusCovidPopup"></th>
            </tr>
          </tbody>
        </table>

      </div>
        <!-- END POPUP -->
    </div>
  <!-- </div>
  <div class="col-md-9 col-12 p-0"> -->
    <div class="map-wrapper">
      <div id="map"></div>
    </div>
    <div class="modal fade" data-backdrop="static" id="myModal" >
    <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Thêm người nhiễm covid</h5>
        <button id="closeModal" type="button" class="close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div class="form-group">
    <label for="namePerson">Tên người nhiễm</label>
      <input type="text" class="form-control" id="namePerson" required>
  </div>
      <div class="form-group">
      <div class="form-group">
    <label for="namePerson">Tuổi</label>
      <input type="number" class="form-control" id="agePerson">
  </div>
      <div class="form-group">
    <label for="statusPerson">Tình trạng</label>
      <select class="form-control" id="statusPerson">
      <option value="f">Nhiễm bệnh</option>
      <option value="t">Khỏi bệnh</option>
    </select>
  </div>

      </div>
      <div class="modal-footer">
        <button id="modalSubmit" type="button" class="btn btn-primary fz-0875">Submit</button>
      </div>
    </div>
        </div>
  </div>
  <script src="./jquery.js" type="text/javascript"></script>
</body>

</html>