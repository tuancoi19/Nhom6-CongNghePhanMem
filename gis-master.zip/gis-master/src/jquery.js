$(document).ready(function () {
  if (!$("#populationCheckbox").is(":checked")) {
    $("#populationCheckbox ~ .info-population").addClass("d-none");
  }

  $("#district").click(function () {
    if ($("#district").is(":checked")) {
      addLayer(districtLayer);
    } else {
      removeLayer(districtLayer);
    }
  });

  $("#village").click(function () {
    if ($("#village").is(":checked")) {
      addLayer(villageLayer);
    } else {
      removeLayer(villageLayer);
    }
  });

  $("#closeModal").click(function () {
    $("#myModal").modal('hide');
    if (actionModal === "POST") {
      startDrawing();
    }
  });

  $("#collapse").click(function () {
    if ($("#header").hasClass("isCollapsed")) {
      $("#header").removeClass("isCollapsed");
    } else {
      $("#header").addClass("isCollapsed");
    }
  });

  $("#popup-closer-covid").click(function () {
    $("#popupCovid").addClass('d-none');
  });

  $("#modalSubmit").click(function () {
    const name = $("#namePerson").val();
    const age = $("#agePerson").val();
    const status = $("#statusPerson").val();
    const { long, lat } = clickedCoord;
    console.log(name, long, lat, idCovid, name && ((long && lat) || idCovid));
    if (name && ((long && lat) || idCovid)) {
      let data = {
        name,
        age: parseInt(age),
        status: status === "t" ? true : false,
        action: actionModal
      }
      if(actionModal === "POST") {
        data = {
          ...data,
          long,
          lat,
        }
      } else {
        data = {
          ...data,
          id: idCovid
        }
      }
      $.ajax({
        url: "pointCoordinate.php",
        type: "POST",
        data,
        dataType: "json",
        success: function (result) {
          if(result?.code === 200) {
            $("#myModal").modal("hide");
          }
          alert(result?.message);
          $("#namePerson").val('');
          $("#agePerson").val('');
          $("#statusPerson").val('f');
          $("#popupCovid").addClass('d-none');
        },
        error: (result) => {
          console.log("Error", result);
        },
      });
      if(actionModal === "POST") {
        startDrawing();
      }
    } else {
      alert("Nhập tên người nhiễm!");
    }
  });

  $("input:checkbox[name='features']").change(function () {
    if ($("#populationCheckbox").is(":checked")) {
      $("#populationCheckbox ~ .info-population").removeClass("d-none");
    } else {
      $("#populationCheckbox ~ .info-population").addClass("d-none");
      arrLayers.forEach(function (el) {
        removeLayer(el);
      });
    }
    if (!$("#covidCheckbox").is(":checked")) {
      removeLayer(covidLayer);
    }
  });

  $("input:radio[name='object']").change(function () {
    const val = $(this).val();

    // Reset vector layer, popup position
    overlay.setPosition(undefined);
    closer.blur();
    vectorLayer.setSource(undefined);

    if (val === "gadm36_vnm_3") {
      removeLayer(districtLayer);
      removeLayer(provinceLayer);
      $("#districtPopup").show();
      $("#provincePopup").show();
      $("#populationCheckbox").prop("checked", false);
      arrLayers.forEach(function (el) {
        removeLayer(el);
      });
    } else if (val === "gadm36_vnm_1") {
      removeLayer(districtLayer);
      removeLayer(villageLayer);
      addLayer(provinceLayer);
      $("#districtPopup").hide();
      $("#provincePopup").hide();
    } else {
      $("#districtPopup").show();
      $("#provincePopup").hide();
      $("#populationCheckbox").prop("checked", false);
      arrLayers.forEach(function (el) {
        removeLayer(el);
      });
      removeLayer(provinceLayer);
      removeLayer(villageLayer);
    }
  });

  $("input:radio[name='youwant']").change(function () {
    const val = $(this).val();
    if ($("#info").is(":checked")) {
      status = "Info";
      map.removeOverlay(covidLayer)
      popupCovid.setPosition(undefined);

    } else {
      status = val;
      vectorLayer.setSource(undefined);
      overlay.setPosition(undefined);
      closer.blur();
    }
    if (val === "addCovid") {
      startDrawing();
      actionModal = "POST";
      $("#myModal h5").text("Thêm người nhiễm");
      idCovid = undefined;
      $("#namePerson").val('');
      $("#agePerson").val('');
      $("#statusPerson").val('f');
    } else {
      map.removeInteraction(draw);
      drawLayer.setSource(undefined)
      actionModal = "PUT";
    }
  });
});
