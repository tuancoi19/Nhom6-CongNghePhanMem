<!-- <?php
$acc_id=$_GET['id'];
$sql="SELECT * FROM taikhoan WHERE id=$acc_id";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($res);
if (isset($_POST['sbm'])) {
    $taikhoan=$_POST['email'];
    $matkhau=$_POST['password'];
    $lever=$_POST['lever'];
    $sql = "UPDATE taikhoan 
    SET taikhoan='$taikhoan',
        matkhau = '$matkhau',
        level = $lever
        WHERE id=$acc_id
    ";
    if(mysqli_query($conn,$sql)){
        header("location: index.php?category=manageAcc");
    }
    
}


?> -->
<div class="col-12 mt-3">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Sửa thông tin tài khoản</h4>
        </div>
        <form role="form" method="post" enctype="multipart/form-data">
        <div class="card-body" id="newUserForm">
        <?php if(isset($error)){ echo $error;} ?>
            <div class="form-group">
                <label class="col-form-label">Email Account</label>
                <input type="text" class="d-block mw-auto w-100 form-fields form-control w-25" name="email" id="email" />
            </div>
            <div class="form-group">
                <label class="col-form-label">Password</label>
                <input type="password" class="d-block mw-auto w-100 form-fields form-control w-25" name="password" id="pwd" />
            </div>
            <div class="form-group">
                <label>Lever</label>
                <select class="custom-select" name="lever" id="level">
                    <option value="">Select one</option>
                    <option value="1">Nhân viên bán hàng</option>
                    <option value="2">Nhân viên chụp ảnh</option>
                </select>
                <div class="invalid-feedback" style="font-size: 12px">Level is required.</div>
            </div>
            <div class="card-bottom">
                <input type="submit" class="btn btn-info d-block ml-auto" id="newUserBtn" name="sbm" value="ADD NEW" />
            </div>
        </div>
        </form>
    </div>
</div>

