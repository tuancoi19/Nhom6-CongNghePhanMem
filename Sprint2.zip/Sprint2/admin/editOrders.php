<?php
$acc_id=$_GET['id'];
$sql="SELECT * FROM donhang WHERE id=$acc_id";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($res);
if (isset($_Orders['sbm'])) {
    $ten=$_Orders['name'];
    $diachi=$_Orders['add'];
    $dienthoai=$_Orders['phone'];
    $diadiem=$_Orders['work'];
    $ngaychup=$_Orders['day'];
    $gia=$_Orders['price'];
    $yeucau=$_Orders['contentPost'];
    $sql = "UPDATE donhang 
    SET ten='$ten',
        diachi = $diachi,
        dienthoai = $dienthoai,
        diadiem = $diadiem,
        ngaychup = $ngaychup,
        gia = $gia,
        yeucau = $yeucau
        WHERE id=$acc_id
    ";
    if(mysqli_query($conn,$sql)){
        header("location: index.php?category=manageOrders");
    }
    
}
?>
<div class="col-12 mt-5">
    <div class="card table-big-boy">
        <div class="card-header ">
            <h4 class="card-title">Sửa thông tin đơn hàng</h4>
            <br />
        </div>
        <div class="card-body" id="newUserForm">
        <form role="form" method="post" enctype="multipart/form-data">
        <?php if(isset($error)){ echo $error;} ?>
            <div class="form-group">
                <label class="col-form-label">Tên khách hàng</label>
                <input type="text" class="form-control" name="name" id="title">
            </div> 
            <div class="form-group">
                <label class="col-form-label">Địa chỉ khách hàng</label>
                <input type="text" class="form-control" name="add" id="title">

            </div> 
            <div class="form-group">
                <label class="col-form-label">SĐT khách hàng</label>
                <input type="text" class="form-control" name="phone" id="title">

            </div> 
            <div class="form-group">
                <label class="col-form-label">Địa chỉ chụp </label>
                <input type="text" class="form-control" name="work" id="title">

            </div> 
            <div class="form-group">
                <label class="col-form-label">Ngày chụp</label>
                <input type="date" class="form-control" name="day" id="title">

            </div> 
            <div class="form-group">
                <label class="col-form-label">Giá</label>
                <input type="number" class="form-control" name="price" id="title">

            </div> 
            <div class="form-group">
                <label class="col-form-label">Ghi chú</label>
                <textarea rows="10" cols="150" name="contentPost" id="contentPost" class="form-control" placeholder="Here can be your description" value=""></textarea>
            </div>       
            <button type="submit" name="sbm" class="btn btn-primary">Cập nhập</button>
            <button type="reset" class="btn btn-default">Làm mới</button>
        </form>
        </div>
    </div>
</div>
